# clip_similarity.py
import torch
import open_clip
from PIL import Image
from io import BytesIO
import requests
import math
from typing import List, Dict, Any

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

print("Loading CLIP model...")
model, _, preprocess = open_clip.create_model_and_transforms(
    "ViT-B-32", pretrained="openai"
)
model.to(DEVICE)
model.eval()
print("CLIP loaded.")


def image_to_embedding(img_bytes: bytes) -> torch.Tensor:
    """画像bytes → 1xD の埋め込みベクトル"""
    img = Image.open(BytesIO(img_bytes)).convert("RGB")
    with torch.no_grad():
        img_t = preprocess(img).unsqueeze(0).to(DEVICE)
        feat = model.encode_image(img_t)
        feat = feat / feat.norm(dim=-1, keepdim=True)
    return feat  # (1, D)


def url_to_bytes(url: str) -> bytes | None:
    try:
        r = requests.get(url, timeout=5)
        r.raise_for_status()
        return r.content
    except Exception as e:
        print("Failed to download image:", url, e)
        return None


def cosine_similarity(a: torch.Tensor, b: torch.Tensor) -> float:
    # a,b: (1,D)
    return float((a @ b.T).item())

def choose_most_similar(
    orig_bytes: bytes,
    ikea_items: List[Dict[str, Any]],
) -> Dict[str, Any] | None:
    """
    orig_bytes: Unityから送られてきた元画像
    ikea_items: search_ikea() の結果リスト
    戻り値: 最も似ている1件 or None
    """
    if not ikea_items:
        return None

    orig_emb = image_to_embedding(orig_bytes)

    best_item = None
    best_score = -math.inf

    for item in ikea_items:
        url = item.get("image")
        if not url:
            continue
        img_b = url_to_bytes(url)
        if not img_b:
            continue
        cand_emb = image_to_embedding(img_b)
        score = cosine_similarity(orig_emb, cand_emb)
        print("similarity", item.get("title"), ":", score)

        if score > best_score:
            best_score = score
            best_item = item

    return best_item
