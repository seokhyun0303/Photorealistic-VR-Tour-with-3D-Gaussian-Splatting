from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from caption_image import generate_furniture_caption_from_bytes, build_search_query
from clip_similarity import choose_most_similar
from ikea_client import search_ikea

app = FastAPI()

# Unity WebGL から叩くなら CORS 設定あると便利
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 必要に応じて絞る
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/detect")
async def ikea_from_image(file: UploadFile = File(...)):
    # 1) 画像 bytes 取得
    img_bytes = await file.read()
    if not img_bytes:
        raise HTTPException(400, "画像が空です")

    # 2) キャプション & クエリ
    caption = generate_furniture_caption_from_bytes(img_bytes)
    query = build_search_query(caption)

    # 3) IKEA 検索
    items = search_ikea(query, limit=10)
    if not items:
        print("No IKEA items found for query:", query)
        print("\n===== BEST MATCH ITEM =====")
        print("(none)")
        print("===== END BEST MATCH =====\n")
        # クライアントには常に同じ形で返す
        return {
            "url": None,
            "image": None,
        }

    # 4) 視覚的に一番似てる item を選ぶ
    best = choose_most_similar(img_bytes, items)

    # ====== ログ出力をシンプルに ======
    print("\n===== BEST MATCH ITEM =====")
    if best:
        print(best.get("url"), best.get("image"))
    else:
        print("(none)")
    print("===== END BEST MATCH =====\n")

    # ====== クライアントへのレスポンスも url / image だけ ======
    if not best:
        return {
            "url": None,
            "image": None,
        }

    return {
        "url": best.get("url"),
        "image": best.get("image"),
    }
