# caption_image.py
import json
import base64
from openai import OpenAI

from ikea_client import search_ikea  # さっきの ikea_client.py

client = OpenAI()  # OPENAI_API_KEY を環境変数から読む


def encode_image_bytes_to_data_url(img_bytes: bytes, mime: str = "image/png") -> str:
    """
    画像のバイト列を base64 の data URL 文字列に変換する
    例: data:image/png;base64,xxxxxx...
    """
    b64 = base64.b64encode(img_bytes).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def extract_json(raw_text: str) -> dict:
    """
    モデル出力から { ... } の JSON 部分だけ抜き出してパースする。
    万が一 余計なテキストやバッククォートが付いても頑張って JSON を取り出す。
    """
    if not raw_text:
        raise ValueError("モデル出力が空です")

    # まずはそのままパースを試す
    try:
        return json.loads(raw_text)
    except Exception:
        pass

    # ダメなら先頭の { 〜 最後の } を抜き出す
    start = raw_text.find("{")
    end = raw_text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"JSONらしき部分が見つかりませんでした:\n{raw_text}")

    json_str = raw_text[start:end + 1]
    return json.loads(json_str)


def generate_furniture_caption_from_bytes(img_bytes: bytes, mime: str = "image/png") -> dict:
    """
    画像バイト列から「家具/照明向けの英語キャプション(JSON)」を生成する。
    戻り値の例:
    {
      "title": "...",
      "description": "...",
      "keywords": ["...", ...]
    }
    """

    image_data_url = encode_image_bytes_to_data_url(img_bytes, mime=mime)

    prompt = """
You are an e-commerce copywriter for furniture and lighting.
Look at the image and output a JSON object with:
- "title": short product-style name (max 10 words, in English)
- "description": 2-3 sentences describing the item (style, shape, material, color, mounting type, number of lights, typical rooms)
- "keywords": array of 5-12 short English search keywords

Return ONLY valid JSON. Do not add any backticks or markdown.
"""

    response = client.responses.create(
        model="gpt-4.1-mini",
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    {
                        "type": "input_image",
                        "image_url": image_data_url,
                        "detail": "low",
                    },
                ],
            }
        ],
        max_output_tokens=400,
    )

    raw_text = response.output[0].content[0].text

    # デバッグ用：生の出力を一度表示
    print("===== RAW MODEL OUTPUT =====")
    print(raw_text)
    print("===== END RAW =====\n")

    return extract_json(raw_text)


def build_search_query(caption: dict, max_len: int = 140) -> str:
    """
    基本は title をそのままクエリに使う。
    ・title が空なら keywords をつなげる
    ・max_len を超えそうなら単語ごとに切って短くする
    """

    title = (caption.get("title") or "").strip()
    keywords = caption.get("keywords") or []

    # 1) まず title 優先
    if title:
        words = title.split()
    else:
        # title が無いときだけ keywords を使用
        words = []
        for k in keywords:
            words.extend(k.split())

    query = ""
    for w in words:
        candidate = (query + " " + w).strip()
        if len(candidate) > max_len:
            break
        query = candidate

    # それでも空なら最後の保険
    if not query and keywords:
        query = keywords[0]

    return query
