# ikea_client.py
from typing import List, Dict, Any
import json

import ikea_api
from ikea_api import run

# US IKEA サイト
CONSTANTS = ikea_api.Constants(country="us", language="en")


def search_ikea(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    ikea_api ライブラリを使って IKEA 検索を行う。
    返り値は「title / price / url / image」などを詰めたリスト。
    """

    # 1) 検索エンドポイントを作る
    search = ikea_api.Search(CONSTANTS)
    endpoint = search.search(query, limit=limit, types=["PRODUCT"])

    # 2) 実際に HTTP を叩く
    raw = run(endpoint)

    # デバッグ用
    print("===== RAW IKEA SEARCH JSON =====")
    print(json.dumps(raw, indent=2, ensure_ascii=False))

    # 3) 商品リスト抽出
    items = _extract_items(raw)

    results: List[Dict[str, Any]] = []
    for it in items:
        # === ここから価格・通貨を salesPrice から取り出す ===
        sales = it.get("salesPrice") or {}
        currency = sales.get("currencyCode")  # "USD"
        numeral = sales.get("numeral")        # 79.99 など

        current = sales.get("current") or {}
        prefix = current.get("prefix", "")          # "$"
        whole = current.get("wholeNumber", "")      # "79"
        decimals = current.get("decimals", "")      # "99"

        # 表示用のきれいな価格文字列
        price_str: str | None
        if whole and decimals:
            price_str = f"{prefix}{whole}.{decimals}"
        elif numeral is not None:
            price_str = f"{prefix}{numeral}"
        else:
            price_str = None

        # URL が相対パスなら補完（us は今の JSON だとフル URLになってるけど一応）
        url = it.get("pipUrl") or it.get("productUrl")
        if isinstance(url, str) and url.startswith("/"):
            url = "https://www.ikea.com" + url

        results.append(
            {
                "source": "ikea",
                "id": it.get("id") or it.get("itemNo") or it.get("itemNumber"),
                "title": it.get("name") or it.get("title"),
                "image": it.get("mainImageUrl") or it.get("imageUrl"),
                # ここを salesPrice ベースに変更
                "price": price_str,
                "currency": currency,
                "url": url,
                "raw": it,  # デバッグ用に生 product も保持
            }
        )

    return results


def _extract_items(raw: Any) -> List[Dict[str, Any]]:
    """
    IKEA の検索レスポンスの中から「商品リストっぽい配列」を抜き出す。
    まずは searchResultPage.products.main.items.product を優先的に見る。
    それでダメなら汎用的なフォールバックに回る。
    """
    # --- ① いま確認できている構造にドンピシャ対応 ---
    try:
        items = raw["searchResultPage"]["products"]["main"]["items"]
        products: List[Dict[str, Any]] = []
        for it in items:
            if not isinstance(it, dict):
                continue
            if it.get("type") != "PRODUCT":
                continue
            prod = it.get("product")
            if isinstance(prod, dict):
                products.append(prod)
        if products:
            return products
    except Exception:
        pass

    # --- ② 汎用フォールバック ---
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, dict)]

    if not isinstance(raw, dict):
        return []

    for key in ("searchResults", "results", "productList", "items", "data"):
        val = raw.get(key)
        if isinstance(val, list):
            return [x for x in val if isinstance(x, dict)]
        if isinstance(val, dict):
            nested = _extract_items(val)
            if nested:
                return nested

    return []
